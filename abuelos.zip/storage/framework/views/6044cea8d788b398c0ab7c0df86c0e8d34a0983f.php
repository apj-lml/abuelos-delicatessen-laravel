

<?php $__env->startPush('mystyles'); ?>
          <style>
          .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
          }

          @media (min-width: 768px) {
            .bd-placeholder-img-lg {
              font-size: 3.5rem;
            }
          }
        </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Checkout Page</h2>
          <ol>
            <li><a href="/">Home</a></li>
            <li>Cart</li>
          </ol>
        </div>
        </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="inner-page">

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('checkout-component')->html();
} elseif ($_instance->childHasBeenRendered('qVX01KE')) {
    $componentId = $_instance->getRenderedChildComponentId('qVX01KE');
    $componentTag = $_instance->getRenderedChildComponentTagName('qVX01KE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qVX01KE');
} else {
    $response = \Livewire\Livewire::mount('checkout-component');
    $html = $response->html();
    $_instance->logRenderedChild('qVX01KE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </section>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abuelos-delicatessen-laravel\resources\views/checkout.blade.php ENDPATH**/ ?>