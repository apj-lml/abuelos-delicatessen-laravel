
<!-- /* -------------------------------------------------------------------------- */
/*                           this will be for admin                           */
/* -------------------------------------------------------------------------- */ -->



<?php $__env->startSection('content'); ?>

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
        <div class="container">
  
          <div class="d-flex justify-content-between align-items-center">
            <h2>Manage Orders</h2>
            <ol>
              <li><a href="/">Home</a></li>
              <li>Manage Orders</li>
            </ol>
          </div>
          </div>
      </section><!-- End Breadcrumbs Section -->
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-sm-12">
            <div class="card">
                

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('manage-orders-component')->html();
} elseif ($_instance->childHasBeenRendered('PGgfOEa')) {
    $componentId = $_instance->getRenderedChildComponentId('PGgfOEa');
    $componentTag = $_instance->getRenderedChildComponentTagName('PGgfOEa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PGgfOEa');
} else {
    $response = \Livewire\Livewire::mount('manage-orders-component');
    $html = $response->html();
    $_instance->logRenderedChild('PGgfOEa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abuelos-delicatessen-laravel\resources\views/manage-orders.blade.php ENDPATH**/ ?>