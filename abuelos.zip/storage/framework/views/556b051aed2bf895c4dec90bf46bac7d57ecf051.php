<div class="row menu-container">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-6 menu-item <?php echo e($product->product_category); ?>">
            <div class="menu-content">
              <a href="/view-product/<?php echo e($product->id); ?>"><?php echo e($product->product_title); ?></a><span>Php <?php echo e($product->product_price); ?></span>
            </div>
            <div class="menu-ingredients">
                <?php echo e($product->product_description); ?>

            </div>
          </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\abuelos-delicatessen-laravel\resources\views/livewire/check-our-product-component.blade.php ENDPATH**/ ?>