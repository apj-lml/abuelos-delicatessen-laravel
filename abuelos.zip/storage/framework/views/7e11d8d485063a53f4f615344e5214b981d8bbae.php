


<?php $__env->startSection('content'); ?>

<main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Checkout Page</h2>
          <ol>
            <li><a href="/">Home</a></li>
            <li>Cart</li>
          </ol>
        </div>
        </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="inner-page">

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('checkout-component', ['cartProducts' => $cartItems])->html();
} elseif ($_instance->childHasBeenRendered('3V1oGqo')) {
    $componentId = $_instance->getRenderedChildComponentId('3V1oGqo');
    $componentTag = $_instance->getRenderedChildComponentTagName('3V1oGqo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3V1oGqo');
} else {
    $response = \Livewire\Livewire::mount('checkout-component', ['cartProducts' => $cartItems]);
    $html = $response->html();
    $_instance->logRenderedChild('3V1oGqo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </section>

</main>
          
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abuelos-delicatessen-laravel\resources\views/cart.blade.php ENDPATH**/ ?>