

<?php $__env->startSection('content'); ?>
<main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>My Orders</h2>
          <ol>
            <li><a href="/">Home</a></li>
            <li>My Orders</li>
          </ol>
        </div>
        </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="inner-page">

    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('my-orders-component')->html();
} elseif ($_instance->childHasBeenRendered('ZJVLEs2')) {
    $componentId = $_instance->getRenderedChildComponentId('ZJVLEs2');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZJVLEs2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZJVLEs2');
} else {
    $response = \Livewire\Livewire::mount('my-orders-component');
    $html = $response->html();
    $_instance->logRenderedChild('ZJVLEs2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abuelos-delicatessen-laravel\resources\views/my-orders.blade.php ENDPATH**/ ?>