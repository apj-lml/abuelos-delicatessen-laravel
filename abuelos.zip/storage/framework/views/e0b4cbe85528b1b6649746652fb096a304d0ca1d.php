

<?php $__env->startPush('mystyles'); ?>
          <style>
          .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
          }

          @media (min-width: 768px) {
            .bd-placeholder-img-lg {
              font-size: 3.5rem;
            }
          }
        </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container">
      <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

        <div class="carousel-inner" role="listbox">

          <!-- Slide 1 -->
          <div class="carousel-item active" style="background-image: url(<?php echo e(asset('/img/slide/steak.jpg')); ?>);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown"><span>Premium</span> Steaks</h2>
                <p class="animate__animated animate__fadeInUp">Premium cut meats present consumers with an opportunity to experience the art of cooking as well as to enjoy a new level of quality and taste.</p>
                <div>
                  <a href="#menu" class="btn-menu animate__animated animate__fadeInUp scrollto">Our Products</a>
                  
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 2 -->
          <div class="carousel-item" style="background-image: url(<?php echo e(asset('/img/slide/scallops.jpg')); ?>);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">All Meat Scallops</h2>
                <p class="animate__animated animate__fadeInUp">All Meat Scallops that are handpicked for premium flavor and tenderness, freshness and showcasing vibrant color.</p>
                <div>
                  <a href="#menu" class="btn-menu animate__animated animate__fadeInUp scrollto">Our Products</a>
                  
                </div>
              </div>
            </div>
          </div>

          <!-- Slide 3 -->
          <div class="carousel-item" style="background-image: url(<?php echo e(asset('/img/slide/oysters.jpg')); ?>);">
            <div class="carousel-container">
              <div class="carousel-content">
                <h2 class="animate__animated animate__fadeInDown">Oysters</h2>
                <p class="animate__animated animate__fadeInUp">Freshly shucked oysters are delightful on their own, but they're really a meal within a meal when paired with an equally hearty and lip smacking side. Choose your favorite raw shellfish and pair them up to truly enjoy the singular taste and freshness of oysters at its best. </p>
                <div>
                  <a href="#menu" class="btn-menu animate__animated animate__fadeInUp scrollto">Our Products</a>
                  
                </div>
              </div>
            </div>
          </div>

        </div>

        <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">

          <div class="col-lg-5 align-items-stretch video-box" style='background-image: url(<?php echo e(asset('/img/top-image.jpg')); ?>);'>
            
          </div>

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch">

            <div class="content">
              <h3>Welcome to our <strong>Store!</strong></h3>
              
              <p class="fst-italic">
                Celebrating the culture of home cooking for everyday culinary creations through:
              </p>
              <ul>
                <li><i class="bx bx-check-double"></i> Fresh and premium ingredients.</li>
                <li><i class="bx bx-check-double"></i> Quality products.</li>
                <li><i class="bx bx-check-double"></i> Fast delivery.</li>
              </ul>
              <p>
                The most convinient way of finding the best ingredients for your dish is one click away! Just order now and we will deliver at your doorstep.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Whu Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="section-title">
          <h2>Why choose <span>Our Store?</span></h2>
          <p>
            We pride ourselves in giving fresh and high quality goods so that you can feel good about what you eat.
          </p>
        </div>

        <div class="row">

          <div class="col-lg-4">
            <div class="box">
              <span>01</span>
              <h4>Quality</h4>
              <p>We only give you guaranteed high quality products.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box">
              <span>02</span>
              <h4>Premium</h4>
              <p>Premium experience with affordable price.</p>
            </div>
          </div>

          <div class="col-lg-4 mt-4 mt-lg-0">
            <div class="box">
              <span>03</span>
              <h4> Delivery</h4>
              <p>Fast delivery within Metro Manila</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Whu Us Section -->

    <!-- ======= Menu Section ======= -->
    <section id="menu" class="menu">
      <div class="container">

        <div class="section-title">
          <h2>Check our <span>Products</span></h2>
        </div>

        <div class="row">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="menu-flters">
              <li data-filter="*" class="filter-active">Show All</li>
              <li data-filter=".Meat">Meat</li>
              <li data-filter=".Seafood">Seafood</li>
              <!-- <li data-filter=".filter-specialty">Specialty</li> -->
            </ul>
          </div>
        </div>

      <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('check-our-product-component')->html();
} elseif ($_instance->childHasBeenRendered('AQJSVSM')) {
    $componentId = $_instance->getRenderedChildComponentId('AQJSVSM');
    $componentTag = $_instance->getRenderedChildComponentTagName('AQJSVSM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AQJSVSM');
} else {
    $response = \Livewire\Livewire::mount('check-our-product-component');
    $html = $response->html();
    $_instance->logRenderedChild('AQJSVSM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        

      </div>
    </section><!-- End Menu Section -->

    <!-- ======= Specials Section ======= -->
    <section id="specials" class="specials mb-0 pb-0">
      <div class="container mb-0 pb-0">

        

        

          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-card-component')->html();
} elseif ($_instance->childHasBeenRendered('4g6dWju')) {
    $componentId = $_instance->getRenderedChildComponentId('4g6dWju');
    $componentTag = $_instance->getRenderedChildComponentTagName('4g6dWju');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4g6dWju');
} else {
    $response = \Livewire\Livewire::mount('product-card-component');
    $html = $response->html();
    $_instance->logRenderedChild('4g6dWju', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

      </div>
    </section><!-- End Specials Section -->

    <!-- ======= Events Section ======= -->
    
    <!-- End Events Section -->

    <!-- ======= Book A Table Section ======= -->
    
    <!-- End Book A Table Section -->

    

    

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2><span>Contact</span> Us</h2>
          <p>Go to our store or contact us with the information below.</p>
        </div>
      </div>

      <div class="map">
        <iframe style="border:0; width: 100%; height: 350px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3861.165619085997!2d121.05826271475885!3d14.58963678980942!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c819c3e18a2d%3A0x37674bcb0e9ef103!2s1605%20ADB%20Ave%2C%20Ortigas%20Center%2C%20Pasig%2C%20Metro%20Manila!5e0!3m2!1sen!2sph!4v1668474818412!5m2!1sen!2sph" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" frameborder="0" allowfullscreen></iframe>
      </div>

      <div class="container-fluid mt-5">

        <div class="info-wrap bg-light">
          <div class="row bg-light">
            <div class="col-lg-3 col-md-6 info bg-light">
              <i class="bi bi-geo-alt"></i>
              <h4>Location:</h4>
              <p>1605 ADB Avenue<br>Pasig City, Philippines</p>
            </div>

            <div class="col-lg-3 col-md-6 info mt-4 mt-lg-0 bg-light">
              <i class="bi bi-clock"></i>
              <h4>Open Hours:</h4>
              <p>Monday-Friday:<br>9:00 AM - 5:00 PM</p>
            </div>

            <div class="col-lg-3 col-md-6 info mt-4 mt-lg-0 bg-light">
              <i class="bi bi-envelope"></i>
              <h4>Email:</h4>
              <p>abuelosdeli@gmail.com<br></p>
            </div>

            <div class="col-lg-3 col-md-6 info mt-4 mt-lg-0 bg-light">
              <i class="bi bi-phone"></i>
              <h4>Call:</h4>
              <p>0915 560 0480<br></p>
            </div>
          </div>
        </div>

        

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->
  <?php $__env->stopSection(); ?>

  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\abuelos-delicatessen-laravel\resources\views/index.blade.php ENDPATH**/ ?>