<div>
    <input wire:model="quantity"
            type="number" min="1" max="15"
            wire:change="updateCart" class="text-center bg-gray-100">
</div>
    